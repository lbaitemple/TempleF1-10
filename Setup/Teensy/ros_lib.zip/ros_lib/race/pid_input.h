#ifndef _ROS_race_pid_input_h
#define _ROS_race_pid_input_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace race
{

  class pid_input : public ros::Msg
  {
    public:
      typedef float _pid_vel_type;
      _pid_vel_type pid_vel;
      typedef float _pid_error_type;
      _pid_error_type pid_error;

    pid_input():
      pid_vel(0),
      pid_error(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_pid_vel;
      u_pid_vel.real = this->pid_vel;
      *(outbuffer + offset + 0) = (u_pid_vel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_pid_vel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_pid_vel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_pid_vel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->pid_vel);
      union {
        float real;
        uint32_t base;
      } u_pid_error;
      u_pid_error.real = this->pid_error;
      *(outbuffer + offset + 0) = (u_pid_error.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_pid_error.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_pid_error.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_pid_error.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->pid_error);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_pid_vel;
      u_pid_vel.base = 0;
      u_pid_vel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_pid_vel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_pid_vel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_pid_vel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->pid_vel = u_pid_vel.real;
      offset += sizeof(this->pid_vel);
      union {
        float real;
        uint32_t base;
      } u_pid_error;
      u_pid_error.base = 0;
      u_pid_error.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_pid_error.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_pid_error.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_pid_error.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->pid_error = u_pid_error.real;
      offset += sizeof(this->pid_error);
     return offset;
    }

    const char * getType(){ return "race/pid_input"; };
    const char * getMD5(){ return "15d51ace2dba29e1b19e1332c9d46c17"; };

  };

}
#endif